"use client";
import React from "react";

function MainComponent() {
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    weight: "",
    height: "",
    age: "",
    activityLevel: "moderate",
    goal: "maintain",
    email: "",
    bloodPressure: "",
    restingHeartRate: "",
    bloodSugar: "",
    cholesterol: "",
    sleepHours: "",
    stressLevel: "low",
    mfaEnabled: false,
    mfaVerified: false,
    mfaCode: "",
    mfaBackupCodes: [],
    mfaRecoveryCodes: [],
    mfaPreferredMethod: "app",
    referralCode: "NUTRITRACK2024",
    referralBalance: 50,
    referralHistory: [
      {
        type: "Credit",
        amount: 10,
        date: "2024-01-15",
        source: "New User Signup",
      },
      {
        type: "Redemption",
        amount: 20,
        date: "2024-01-10",
        source: "Premium Features",
      },
      {
        type: "Credit",
        amount: 10,
        date: "2024-01-05",
        source: "New User Signup",
      },
    ],
    socialConnections: {
      google: {
        connected: false,
        email: "",
        profilePic: "",
        lastLogin: null,
      },
      facebook: {
        connected: false,
        email: "",
        profilePic: "",
        lastLogin: null,
      },
      apple: {
        connected: false,
        email: "",
        profilePic: "",
        lastLogin: null,
      },
    },
    sharingPreferences: {
      achievements: true,
      workouts: true,
      mealPlans: false,
      progress: true,
      autoShare: false,
      shareWithFriends: true,
      shareWithPublic: false,
      privacyLevel: "friends",
    },
    notifications: {
      mealReminders: true,
      weeklyReport: true,
      achievementAlerts: true,
      pushEnabled: true,
      emailEnabled: true,
      smsEnabled: false,
      notificationTime: "09:00",
      customSounds: false,
      notificationPriority: "normal",
      quietHours: { start: "22:00", end: "07:00" },
      weekendReminders: true,
      nutritionAlerts: true,
      hydrationReminders: true,
      exerciseReminders: true,
    },
    preferences: {
      measurementUnit: "imperial",
      language: "english",
      theme: "light",
    },
    connectedDevices: {
      fitbit: {
        connected: false,
        lastSync: null,
        permissions: [],
        dataTypes: ["steps", "heartRate", "sleep", "exercise"],
        syncFrequency: "realtime",
        batteryLevel: null,
      },
      appleHealth: {
        connected: false,
        lastSync: null,
        permissions: [],
        dataTypes: ["activity", "vitals", "nutrition", "sleep"],
        syncFrequency: "hourly",
        lastHealthKit: null,
      },
      googleFit: {
        connected: false,
        lastSync: null,
        permissions: [],
        dataTypes: ["fitness", "activity", "nutrition"],
        syncFrequency: "realtime",
        lastWorkout: null,
      },
      garmin: {
        connected: false,
        lastSync: null,
        permissions: [],
        dataTypes: ["activity", "stress", "sleep", "heartRate"],
        syncFrequency: "realtime",
        deviceModel: null,
      },
    },
    subscription: {
      plan: "premium",
      status: "active",
      renewalDate: "2024-04-01",
      features: ["analytics", "consultation", "mealPlanner"],
      paymentMethod: "credit_card",
      autoRenew: true,
    },
  });

  const [showMFASetup, setShowMFASetup] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);
  const [showBackupCodes, setShowBackupCodes] = useState(false);
  const [showRecoveryCodes, setShowRecoveryCodes] = useState(false);
  const [mfaStep, setMfaStep] = useState(1);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleNotificationChange = (setting, value) => {
    setProfileData((prev) => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [setting]: value !== undefined ? value : !prev.notifications[setting],
      },
    }));
  };

  const handlePreferenceChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [name]: value,
      },
    }));
  };

  const handleDeviceConnection = (device) => {
    setProfileData((prev) => ({
      ...prev,
      connectedDevices: {
        ...prev.connectedDevices,
        [device]: {
          ...prev.connectedDevices[device],
          connected: !prev.connectedDevices[device].connected,
          lastSync: new Date().toISOString(),
        },
      },
    }));
  };

  const handleSyncFrequencyChange = (device, frequency) => {
    setProfileData((prev) => ({
      ...prev,
      connectedDevices: {
        ...prev.connectedDevices,
        [device]: {
          ...prev.connectedDevices[device],
          syncFrequency: frequency,
        },
      },
    }));
  };

  const handleSocialConnection = (provider) => {
    setProfileData((prev) => ({
      ...prev,
      socialConnections: {
        ...prev.socialConnections,
        [provider]: {
          ...prev.socialConnections[provider],
          connected: !prev.socialConnections[provider].connected,
        },
      },
    }));
  };

  const handleSharingPreference = (preference) => {
    setProfileData((prev) => ({
      ...prev,
      sharingPreferences: {
        ...prev.sharingPreferences,
        [preference]: !prev.sharingPreferences[preference],
      },
    }));
  };

  const handlePrivacyLevel = (level) => {
    setProfileData((prev) => ({
      ...prev,
      sharingPreferences: {
        ...prev.sharingPreferences,
        privacyLevel: level,
      },
    }));
  };

  const handleMFASetup = () => {
    setShowMFASetup(!showMFASetup);
  };

  const handleMFAMethodChange = (method) => {
    setProfileData((prev) => ({
      ...prev,
      mfaPreferredMethod: method,
    }));
  };

  const calculateCalories = (data) => {
    if (!data.weight || !data.height || !data.age) return 0;

    const bmr = 10 * data.weight + 6.25 * data.height - 5 * data.age;
    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      very: 1.725,
      extra: 1.9,
    };

    const goalMultipliers = {
      lose: 0.8,
      maintain: 1,
      gain: 1.2,
    };

    return Math.round(
      bmr * activityMultipliers[data.activityLevel] * goalMultipliers[data.goal]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-[#2C3E50] p-4">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-roboto text-white">
            NutriTrack Profile
          </h1>
          <button className="text-white">
            <i className="fas fa-save mr-2"></i>Save Changes
          </button>
        </div>
      </nav>

      <main className="container mx-auto p-4">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-roboto mb-4">Personal Information</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  name="firstName"
                  placeholder="First Name"
                  className="w-full p-2 border rounded"
                  value={profileData.firstName}
                  onChange={handleInputChange}
                />
                <input
                  type="text"
                  name="lastName"
                  placeholder="Last Name"
                  className="w-full p-2 border rounded"
                  value={profileData.lastName}
                  onChange={handleInputChange}
                />
              </div>
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="w-full p-2 border rounded"
                value={profileData.email}
                onChange={handleInputChange}
              />
              <div className="grid grid-cols-3 gap-4">
                <input
                  type="number"
                  name="weight"
                  placeholder="Weight"
                  className="w-full p-2 border rounded"
                  value={profileData.weight}
                  onChange={handleInputChange}
                />
                <input
                  type="number"
                  name="height"
                  placeholder="Height"
                  className="w-full p-2 border rounded"
                  value={profileData.height}
                  onChange={handleInputChange}
                />
                <input
                  type="number"
                  name="age"
                  placeholder="Age"
                  className="w-full p-2 border rounded"
                  value={profileData.age}
                  onChange={handleInputChange}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  name="bloodPressure"
                  placeholder="Blood Pressure"
                  className="w-full p-2 border rounded"
                  value={profileData.bloodPressure}
                  onChange={handleInputChange}
                />
                <input
                  type="number"
                  name="restingHeartRate"
                  placeholder="Resting Heart Rate"
                  className="w-full p-2 border rounded"
                  value={profileData.restingHeartRate}
                  onChange={handleInputChange}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  name="bloodSugar"
                  placeholder="Blood Sugar"
                  className="w-full p-2 border rounded"
                  value={profileData.bloodSugar}
                  onChange={handleInputChange}
                />
                <input
                  type="number"
                  name="cholesterol"
                  placeholder="Cholesterol"
                  className="w-full p-2 border rounded"
                  value={profileData.cholesterol}
                  onChange={handleInputChange}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  name="sleepHours"
                  placeholder="Sleep Hours"
                  className="w-full p-2 border rounded"
                  value={profileData.sleepHours}
                  onChange={handleInputChange}
                />
                <select
                  name="stressLevel"
                  className="w-full p-2 border rounded"
                  value={profileData.stressLevel}
                  onChange={handleInputChange}
                >
                  <option value="low">Low Stress</option>
                  <option value="moderate">Moderate Stress</option>
                  <option value="high">High Stress</option>
                </select>
              </div>
              <select
                name="activityLevel"
                className="w-full p-2 border rounded"
                value={profileData.activityLevel}
                onChange={handleInputChange}
              >
                <option value="sedentary">Sedentary</option>
                <option value="light">Lightly Active</option>
                <option value="moderate">Moderately Active</option>
                <option value="very">Very Active</option>
                <option value="extra">Extra Active</option>
              </select>
              <select
                name="goal"
                className="w-full p-2 border rounded"
                value={profileData.goal}
                onChange={handleInputChange}
              >
                <option value="lose">Lose Weight</option>
                <option value="maintain">Maintain Weight</option>
                <option value="gain">Gain Weight</option>
              </select>
            </div>
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-roboto mb-2">
                Calculated Daily Calories
              </h3>
              <p className="text-2xl font-bold text-[#3498DB]">
                {calculateCalories(profileData)} kcal
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Based on your stats and goals
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Notifications</h2>
              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Notification Methods</label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>Push Notifications</span>
                      <button
                        onClick={() => handleNotificationChange("pushEnabled")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.notifications.pushEnabled
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.notifications.pushEnabled
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Email Notifications</span>
                      <button
                        onClick={() => handleNotificationChange("emailEnabled")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.notifications.emailEnabled
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.notifications.emailEnabled
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SMS Notifications</span>
                      <button
                        onClick={() => handleNotificationChange("smsEnabled")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.notifications.smsEnabled
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.notifications.smsEnabled
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block mb-2">Notification Time</label>
                  <input
                    type="time"
                    name="notificationTime"
                    className="w-full p-2 border rounded"
                    value={profileData.notifications.notificationTime}
                    onChange={(e) =>
                      handleNotificationChange(
                        "notificationTime",
                        e.target.value
                      )
                    }
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Meal Reminders</span>
                    <button
                      onClick={() => handleNotificationChange("mealReminders")}
                      className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                        profileData.notifications.mealReminders
                          ? "bg-[#2ECC71]"
                          : "bg-gray-200"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                          profileData.notifications.mealReminders
                            ? "translate-x-6"
                            : "translate-x-0"
                        }`}
                      ></div>
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Weekly Report</span>
                    <button
                      onClick={() => handleNotificationChange("weeklyReport")}
                      className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                        profileData.notifications.weeklyReport
                          ? "bg-[#2ECC71]"
                          : "bg-gray-200"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                          profileData.notifications.weeklyReport
                            ? "translate-x-6"
                            : "translate-x-0"
                        }`}
                      ></div>
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Achievement Alerts</span>
                    <button
                      onClick={() =>
                        handleNotificationChange("achievementAlerts")
                      }
                      className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                        profileData.notifications.achievementAlerts
                          ? "bg-[#2ECC71]"
                          : "bg-gray-200"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                          profileData.notifications.achievementAlerts
                            ? "translate-x-6"
                            : "translate-x-0"
                        }`}
                      ></div>
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Custom Notification Sounds</span>
                    <button
                      onClick={() => handleNotificationChange("customSounds")}
                      className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                        profileData.notifications.customSounds
                          ? "bg-[#2ECC71]"
                          : "bg-gray-200"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                          profileData.notifications.customSounds
                            ? "translate-x-6"
                            : "translate-x-0"
                        }`}
                      ></div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Preferences</h2>
              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Measurement Unit</label>
                  <select
                    name="measurementUnit"
                    className="w-full p-2 border rounded"
                    value={profileData.preferences.measurementUnit}
                    onChange={handlePreferenceChange}
                  >
                    <option value="imperial">Imperial (lb, ft)</option>
                    <option value="metric">Metric (kg, cm)</option>
                  </select>
                </div>
                <div>
                  <label className="block mb-2">Language</label>
                  <select
                    name="language"
                    className="w-full p-2 border rounded"
                    value={profileData.preferences.language}
                    onChange={handlePreferenceChange}
                  >
                    <option value="english">English</option>
                    <option value="spanish">Spanish</option>
                    <option value="french">French</option>
                  </select>
                </div>
                <div>
                  <label className="block mb-2">Theme</label>
                  <select
                    name="theme"
                    className="w-full p-2 border rounded"
                    value={profileData.preferences.theme}
                    onChange={handlePreferenceChange}
                  >
                    <option value="light">Light</option>
                    <option value="dark">Dark</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Security</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Two-Factor Authentication</h3>
                    <p className="text-sm text-gray-500">
                      Add an extra layer of security
                    </p>
                  </div>
                  <button
                    onClick={handleMFASetup}
                    className={`px-4 py-2 rounded ${
                      profileData.mfaEnabled
                        ? "bg-[#2ECC71] text-white"
                        : "bg-[#3498DB] text-white"
                    }`}
                  >
                    {profileData.mfaEnabled ? "Manage 2FA" : "Enable 2FA"}
                  </button>
                </div>
                {showMFASetup && (
                  <div className="p-4 bg-gray-50 rounded-lg space-y-4">
                    <div className="flex justify-between mb-4">
                      <div className="space-x-2">
                        {[1, 2, 3].map((step) => (
                          <span
                            key={step}
                            className={`inline-block w-3 h-3 rounded-full ${
                              mfaStep >= step ? "bg-[#3498DB]" : "bg-gray-300"
                            }`}
                          ></span>
                        ))}
                      </div>
                      <select
                        value={profileData.mfaPreferredMethod}
                        onChange={(e) => handleMFAMethodChange(e.target.value)}
                        className="text-sm border rounded p-1"
                      >
                        <option value="app">Authenticator App</option>
                        <option value="sms">SMS</option>
                        <option value="email">Email</option>
                      </select>
                    </div>
                    {mfaStep === 1 && (
                      <div className="text-center">
                        <img
                          src="/qr-placeholder.png"
                          alt="2FA QR Code"
                          className="mx-auto w-48 h-48 mb-4"
                        />
                        <p className="text-sm text-gray-600 mb-4">
                          Scan this QR code with your authenticator app
                        </p>
                        <button
                          onClick={() => setMfaStep(2)}
                          className="bg-[#3498DB] text-white px-4 py-2 rounded w-full"
                        >
                          Next
                        </button>
                      </div>
                    )}
                    {mfaStep === 2 && (
                      <div>
                        <p className="mb-2">Enter verification code:</p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            name="mfaCode"
                            maxLength="6"
                            className="w-full p-2 border rounded"
                            value={profileData.mfaCode}
                            onChange={handleInputChange}
                          />
                          <button
                            onClick={() => setMfaStep(3)}
                            className="bg-[#3498DB] text-white px-4 py-2 rounded"
                          >
                            Verify
                          </button>
                        </div>
                      </div>
                    )}
                    {mfaStep === 3 && (
                      <div>
                        <h4 className="font-medium mb-2">Recovery Options</h4>
                        <div className="space-y-4">
                          <div className="p-4 bg-white rounded-lg border">
                            <h5 className="font-medium mb-2">Backup Codes</h5>
                            <div className="grid grid-cols-2 gap-2">
                              {profileData.mfaBackupCodes.map((code, index) => (
                                <div
                                  key={index}
                                  className="p-2 bg-gray-50 rounded text-center font-mono text-sm"
                                >
                                  {code}
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="p-4 bg-white rounded-lg border">
                            <h5 className="font-medium mb-2">Recovery Email</h5>
                            <input
                              type="email"
                              placeholder="Backup email address"
                              className="w-full p-2 border rounded"
                            />
                          </div>
                          <button
                            onClick={() => {
                              setShowMFASetup(false);
                              setMfaStep(1);
                            }}
                            className="w-full bg-[#2ECC71] text-white py-2 rounded"
                          >
                            Complete Setup
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Connected Devices</h2>
              <div className="space-y-4">
                {Object.entries(profileData.connectedDevices).map(
                  ([device, data]) => (
                    <div key={device} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <i
                            className={`fab fa-${
                              device === "appleHealth" ? "apple" : device
                            } text-[#000000]`}
                          ></i>
                          <div>
                            <span className="font-medium">
                              {device
                                .replace(/([A-Z])/g, " $1")
                                .replace(/^./, (str) => str.toUpperCase())}
                            </span>
                            {data.connected && (
                              <p className="text-xs text-gray-500">
                                Sync: {data.syncFrequency}
                              </p>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => handleDeviceConnection(device)}
                          className={`px-4 py-2 rounded ${
                            data.connected
                              ? "bg-[#2ECC71] text-white"
                              : "bg-gray-200"
                          }`}
                        >
                          {data.connected ? "Connected" : "Connect"}
                        </button>
                      </div>
                      {data.connected && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-500">Last Synced:</span>
                            <span>
                              {new Date(data.lastSync).toLocaleString()}
                            </span>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-gray-500">Data Types:</p>
                            <div className="flex flex-wrap gap-2">
                              {data.dataTypes.map((type) => (
                                <span
                                  key={type}
                                  className="px-2 py-1 bg-gray-100 rounded-full text-xs"
                                >
                                  {type.replace("_", " ")}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <button className="text-[#3498DB] text-sm">
                              Manage Data Access
                            </button>
                            <select
                              className="text-sm border rounded p-1"
                              value={data.syncFrequency}
                              onChange={(e) =>
                                handleSyncFrequencyChange(
                                  device,
                                  e.target.value
                                )
                              }
                            >
                              <option value="realtime">Real-time</option>
                              <option value="hourly">Hourly</option>
                              <option value="daily">Daily</option>
                            </select>
                          </div>
                        </div>
                      )}
                    </div>
                  )
                )}
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Subscription</h2>
              <div className="space-y-4">
                <div className="p-4 bg-[#E8F6FF] rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="font-medium">Current Plan: Premium</h3>
                      <p className="text-sm text-gray-600">
                        Renews on April 1, 2024
                      </p>
                    </div>
                    <span className="bg-[#2ECC71] text-white px-3 py-1 rounded-full text-sm">
                      Active
                    </span>
                  </div>
                </div>
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">Plan Features</h3>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <i className="fas fa-check text-[#2ECC71]"></i>
                      <span>Advanced Analytics</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <i className="fas fa-check text-[#2ECC71]"></i>
                      <span>Nutritionist Consultations</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <i className="fas fa-check text-[#2ECC71]"></i>
                      <span>Meal Plan Generator</span>
                    </li>
                  </ul>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 bg-[#3498DB] text-white py-2 rounded-lg">
                    Upgrade Plan
                  </button>
                  <button className="flex-1 border border-[#E74C3C] text-[#E74C3C] py-2 rounded-lg">
                    Cancel Subscription
                  </button>
                </div>
                <button className="w-full text-gray-500 text-sm">
                  View Billing History
                </button>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Social Connections</h2>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">Login Methods</h3>
                  <div className="space-y-3">
                    {Object.entries(profileData.socialConnections).map(
                      ([provider, data]) => (
                        <div
                          key={provider}
                          className="flex items-center justify-between p-3 border rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <i
                              className={`fab fa-${provider} text-2xl ${
                                provider === "google"
                                  ? "text-[#DB4437]"
                                  : provider === "facebook"
                                  ? "text-[#4267B2]"
                                  : "text-[#000000]"
                              }`}
                            ></i>
                            <div>
                              <p className="font-medium capitalize">
                                {provider}
                              </p>
                              {data.connected && (
                                <p className="text-sm text-gray-500">
                                  {data.email}
                                </p>
                              )}
                            </div>
                          </div>
                          <button
                            className={`px-4 py-2 rounded-lg ${
                              data.connected
                                ? "bg-gray-200 text-gray-700"
                                : "bg-[#3498DB] text-white"
                            }`}
                            onClick={() => handleSocialConnection(provider)}
                          >
                            {data.connected ? "Disconnect" : "Connect"}
                          </button>
                        </div>
                      )
                    )}
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium mb-4">Sharing Preferences</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Share Achievements</span>
                      <button
                        onClick={() => handleSharingPreference("achievements")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.sharingPreferences.achievements
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.sharingPreferences.achievements
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Share Workouts</span>
                      <button
                        onClick={() => handleSharingPreference("workouts")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.sharingPreferences.workouts
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.sharingPreferences.workouts
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Share Meal Plans</span>
                      <button
                        onClick={() => handleSharingPreference("mealPlans")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.sharingPreferences.mealPlans
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.sharingPreferences.mealPlans
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Auto-Share Progress</span>
                      <button
                        onClick={() => handleSharingPreference("autoShare")}
                        className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                          profileData.sharingPreferences.autoShare
                            ? "bg-[#2ECC71]"
                            : "bg-gray-200"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                            profileData.sharingPreferences.autoShare
                              ? "translate-x-6"
                              : "translate-x-0"
                          }`}
                        ></div>
                      </button>
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block mb-2">Privacy Level</label>
                    <select
                      className="w-full p-2 border rounded-lg"
                      value={profileData.sharingPreferences.privacyLevel}
                      onChange={(e) => handlePrivacyLevel(e.target.value)}
                    >
                      <option value="private">Private</option>
                      <option value="friends">Friends Only</option>
                      <option value="public">Public</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-roboto mb-4">Referral Program</h2>
              <div className="space-y-4">
                <div className="p-4 bg-[#E8F6FF] rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="font-medium">Your Referral Code</h3>
                      <p className="text-2xl font-mono mt-2">
                        {profileData.referralCode}
                      </p>
                    </div>
                    <button className="text-[#3498DB]">
                      <i className="fas fa-copy"></i>
                    </button>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Share this code and earn $10 credit for each new user
                  </p>
                </div>

                <div className="flex gap-2">
                  <button className="flex-1 bg-[#3498DB] text-white py-2 rounded-lg">
                    <i className="fab fa-facebook-f mr-2"></i>Share
                  </button>
                  <button className="flex-1 bg-[#1DA1F2] text-white py-2 rounded-lg">
                    <i className="fab fa-twitter mr-2"></i>Tweet
                  </button>
                  <button className="flex-1 bg-[#25D366] text-white py-2 rounded-lg">
                    <i className="fab fa-whatsapp mr-2"></i>Share
                  </button>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Credit Balance</h3>
                    <span className="text-2xl font-bold text-[#2ECC71]">
                      ${profileData.referralBalance}
                    </span>
                  </div>
                  <button className="w-full bg-[#2ECC71] text-white py-2 rounded-lg">
                    Redeem Credits
                  </button>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium mb-4">Redemption History</h3>
                  <div className="space-y-3">
                    {profileData.referralHistory.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center text-sm"
                      >
                        <div>
                          <p className="font-medium">{item.type}</p>
                          <p className="text-gray-500">{item.date}</p>
                        </div>
                        <span
                          className={
                            item.type === "Credit"
                              ? "text-[#2ECC71]"
                              : "text-[#E74C3C]"
                          }
                        >
                          {item.type === "Credit" ? "+" : "-"}${item.amount}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default MainComponent;